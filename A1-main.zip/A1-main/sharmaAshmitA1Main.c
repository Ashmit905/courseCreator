/**********************sharmaAshmitA1Main.c****************
Student ID: 1228390
Due Date: Febuary 3rd 2023
Course: CIS*2500
I have exclusive control over this submission via my password.
By including this header comment, I certify that:
1) I have read and understood the policy on academic integrity.
2) I have completed Moodle's module on academic integrity.
3) I have achieved at least 80% on the academic integrity quiz
I assert that this work is my own. I have appropriate acknowledged
any and all material that I have used, be it directly quoted or
paraphrased. Furthermore, I certify that this assignment was written
by me in its entirety.
*****************************************************/
#include "givenA1.h"


int main( int argc, char* argv[]) {
   // Declaring all my Variables
    int x = 0;
    int a = 0;
    int k = 0;
    int j = 0;
    int value;
    int digit;
    int foundCourse;
    float average;
    char taughtBy [NUMBER_PROFS][MAX_STR];
    int numberCome;
    char cName [MAX_STR];
    int totalProf;
    struct courseStruct courseInfo[NUMBER_COURSES];
    struct profStruct profInfo[NUMBER_PROFS];
    char cNameFound [MAX_STR];
    int courseNum;
    char profsNCourses [NUMBER_PROFS][MAX_STR];

//Function def 2
    // Prints read courses
    printf("Read courses \n");
      // Function call
    readCourse(argv[1], courseInfo);
    // Prints the course Names
    for( x = 0; x < NUMBER_COURSES; x++){
        printf("%s\n", courseInfo[x].courseName);
    }
     // Prints the course Ids
    for( x = 0; x < NUMBER_COURSES; x++){
        printf("%d\n", courseInfo[x].courseID);
    }

    // New line indicator
    printf("\n");

 // Function def 3
 // Prints read prof and courses taught
    printf("readProfandCoursesTaught \n");
     // Function Call
    readProfAndCoursesTaught (argv[2], profInfo, courseInfo);
    // Loop runs through Profs and prints all the Prof Names
     for( x = 0; x < NUMBER_PROFS; x++){
        printf("\n");
        printf("%s: ",profInfo[x].profName);
        printf(" ");
        // Loop runs through courses and prints the courses taught
      for( a = 0; a < NUMBER_COURSES; a++){
        printf("%d", profInfo[x].coursesTaught[a]);
        printf(" ");
       }
     }
     
    // New line
     printf("\n");

     // Function def 4
     // Prints N courses
     printf("nCourses ");
     // New line
     printf("\n");
    // Give n a value
     printf(" Give n a value \n");
   // User input
     scanf("%d", &value);
    // New line
     printf("\n");
     // Function Call
     totalProf = nCourses(value, profInfo, profsNCourses);
     printf("\n");
     printf("The following are the professors who teach %d or more courses are: %d", value, totalProf);
     printf("\n");
     // Loops through totalProf
     for( k = 0; k < totalProf; k++){
        printf("%s", profsNCourses[k]);
        printf("\n");
     }
       printf("\n");

    // Function def 5
    //Prints getcoursename
     printf("getCourseName \n");

     printf("Enter the following course code \n");
   // User input
     scanf("%d", &digit);
     // Function Call
     getCourseName(digit, cNameFound, courseInfo);
     printf(" The following course is %s \n", cNameFound);


     
     printf("\n");

       //Function def 6
       //  Print statements
       printf("getCourseNum \n");
       printf("\n");
       printf("Enter the course name!");
      getchar();
      // Fgets to read course name
      fgets(cName, MAX_STR, stdin);
      // Deals with length of string and new line
      cName[strlen(cName)-1] = '\0';
      printf("%s", cName);
      // Function call
      getCourseNum(cName, &numberCome, courseInfo);
      printf("The course Number for the following course %s is: %d \n", cName, numberCome);
      printf("\n");

     
    // Function def 7
    // Prints profsteachingCourse
     printf("profsTeachingCourse \n");

     printf("Enter the Number for the course");
     // User input
      scanf("%d", &courseNum);
      // Function Call
      foundCourse = profsTeachingCourse(courseNum, profInfo, taughtBy);
      // if user input equals to 0 then the course is not found
      if(foundCourse == 0){
         printf("This course was not found! \n");
      }
      // if user input is greater than 0 then you get the course
      if(foundCourse > 0){
         printf("This course is Taught by!  \n");

         for( j = 0; j < foundCourse; j++){
            printf("%s", taughtBy[j]);
         }
      }

     printf("\n");

    // Function def 8
    // prints averageNumcourse
     printf("AverageNumCourses: ");
   
     printf("\n");
     // Function call
     average = avgNumCourses (profInfo);
     // prints the float value
     printf("Average number of courses taught by a professor is: %1f", average);
     // New line

     printf("\n");



    return 0;
    // end of my main
}