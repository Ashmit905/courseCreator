/*student Name: Ashmit Sharma
Student ID: 1228390
Due Date: Feb 3 2023
Course: CIS*2500
I have exclusive control over this submission via my password.
By including this header comment, I certify that:
1) I have read and understood the policy on academic integrity.
2) I have completed Moodle's module on academic integrity.
3) I have achieved at least 80% on the academic integrity quiz
I assert that this work is my own. I have appropriate acknowledged
any and all material that I have used, be it directly quoted or
paraphrased. Furthermore, I certify that this assignment was written
by me in its entirety.*/

// Function Definitions
#include "givenA1.h"
#include <math.h>


// Function Def 1
FILE *openFileForReading(char fileName [MAX_STR]){   
    FILE *ftpr;
    // Opens and reads the file
    ftpr = fopen(fileName, "r");
    // returns the file pointer
    return ftpr;

}
// Function def 2
int readCourse (char filename [MAX_STR], struct courseStruct courseInfo [NUMBER_COURSES]){
    // Initializing your variables
   int x;
   int i;
   int check = 0;
   char nameCourse [MAX_STR];
   char lineMake = '\n';
   // Opens the file
   FILE *ftpr;
   ftpr = openFileForReading(filename);
   // While Loop
   while(!feof(ftpr)){
    fscanf(ftpr, "%c",&lineMake);
    // Statement increments a new line
    if(lineMake== '\n'){
        check++;
    }
   }
   // moves the file pointer
   fseek(ftpr, 0, SEEK_SET);
  
   //if the file is invalid
   if(ftpr== NULL){
    printf("This file does not exist! ");
    return -1;

   }
   // Loops through the courses
   for( x = 0; x < NUMBER_COURSES; x++) {
    fgets(nameCourse, MAX_STR, ftpr); // Reads the text file
    nameCourse[strlen(nameCourse)-1] = '\0'; // New line
    strcpy(courseInfo[x].courseName, nameCourse); // Copies the string


   }
   // reads all the courses and loops through number of courses
   for( i = 0; i < NUMBER_COURSES; i++){
     fscanf(ftpr, "%d", &courseInfo[i].courseID);

   }
 
   return 1;
 
}
//function def 3
int readProfAndCoursesTaught (char filename [MAX_STR],struct profStruct profInfo [NUMBER_PROFS],struct courseStruct courseInfo [NUMBER_COURSES]){
   // declaring your variables
    int x;
    int a;
   // Opens the file
    FILE *ftpr;
    ftpr = openFileForReading(filename);

    char arrayCourse [NUMBER_PROFS][MAX_STR];
    // Loops through the number of Profs
    for( x = 0; x < NUMBER_PROFS; x++){
        fscanf(ftpr, "%s", profInfo[x].profName);
    }
    // Loops through the Number of Profs
    for ( x = 0; x < NUMBER_PROFS; x++){
        fscanf(ftpr, "%s", arrayCourse[x]);
    }
    // Checks for courseID and the Courses Taught for in both cases
    for( x = 0; x < NUMBER_PROFS; x++){
        for( a = 0; a < NUMBER_COURSES; a++){
            if(arrayCourse[x][a] == 'y' || arrayCourse[x][a] == 'Y'){
                profInfo[x].coursesTaught[a] = courseInfo[a].courseID;
            }
            else if(arrayCourse[x][a] == 'n' || arrayCourse[x][a] == 'N'){
                profInfo[x].coursesTaught[a] = -1;
            }
        }
    }

    return 1;
}

// function def 4
int nCourses (int n,struct profStruct profInfo [NUMBER_PROFS],char profsNCourses [NUMBER_PROFS][MAX_STR]) {
    // Declaring your variables
   int x;
   int k;
   int checker;
   int profNum = 0;
   // Nested for loop
   for( x = 0; x < NUMBER_PROFS; x++){
     checker = 0;
     for(k = 0; k < NUMBER_COURSES; k++){
        if(profInfo[x].coursesTaught[k] != -1){
            checker++;
        }
     }
     // if the course assignment is greater then or equal to three then return profnames
     if(checker >= n){
        strcpy(profsNCourses[profNum], profInfo[x].profName);
        profNum++;
     }
   }
   return profNum;
}
// function def 5
int getCourseName (int courseNum, char cNameFound [MAX_STR], struct courseStruct courseInfo [NUMBER_COURSES]) {
    // Declaring my variable
    int x;
    // For loop and if statement inside copies the string and returns the coursename
    for( x = 0; x < NUMBER_COURSES; x++){
        if(courseInfo[x].courseID == courseNum) {
            strcpy(cNameFound, courseInfo[x].courseName);
            return 1;
        }
    }

    return 0;

}
 //function def 6
 int getCourseNum ( char cName [MAX_STR], int * cNumFound, struct courseStruct courseInfo [NUMBER_COURSES]) {
    // Declaring my variables
    int x;
    int compareResult;
    // Loops through the Number of courses
    for( x = 0; x < NUMBER_COURSES; x++){
        compareResult = strcmp(cName, courseInfo[x].courseName); //Stored value of strcmp into compareResult
        if(compareResult == 0){
            *cNumFound = courseInfo[x].courseID;
            return 1;
        }
    }
        return 0;
    

}
//function def 7
 int profsTeachingCourse (int courseNum, struct profStruct profInfo [NUMBER_PROFS], char taughtBy [NUMBER_PROFS][MAX_STR]) {
    // Declaring my Variables
    int j;
    int x;
    int countProf = 0;
    // Loop runs through the number of profs
   for( j = 0; j < NUMBER_PROFS; j++){
    // Loops runs through the number of courses
     for( x = 0; x < NUMBER_COURSES; x++){
          if(profInfo[j].coursesTaught[x] == courseNum){
            // compares the strings
            strcpy(taughtBy[countProf],profInfo[j].profName);
            countProf++;
          }
    }
   }
    // if a undesired value is inputted then the course is not found
   if(countProf == 0)
    {
        return 0;
    }

    return countProf;
}

float avgNumCourses (struct profStruct profInfo [NUMBER_PROFS]) {
    // Declaring my variables
    int j;
    int x;
    int checker = 0;
    float calculator = 6;
    float average;
      // Loop runs through the Number of professors
    for(j = 0; j < NUMBER_PROFS; j++){
        // Loop runs through the Number of Courses
        for(x = 0; x < NUMBER_COURSES; x++){
            // If statement does the increment
         if(profInfo[j].coursesTaught[x] != -1){
            checker++;
          }
        }
    }
    // You use average because you want to round that value up
    // do ceil average, because you want average value to be rounded up
  average = checker/calculator;
  average = ceil(average);
   // Return average
  return average;
}
// End of my function definitions
